#!/usr/bin/env python3
"""
make_figures.py — regenerate every figure in the paper from the prediction files.

Figure 1 (architecture) is a schematic and is drawn from constants, not data.
Figures 2-5 are drawn entirely from corpus/ and predictions/pooled/.

USAGE
    python code/make_figures.py --preds predictions/pooled --corpus corpus --out figures
"""
import argparse
import glob
import os
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
from scipy import stats
from sklearn.metrics import precision_recall_fscore_support, f1_score

plt.rcParams.update(
    {"font.family": "serif", "font.size": 9, "axes.linewidth": 0.8, "savefig.dpi": 300}
)

CONFIGS = {
    "Full MAGNET-NFR": "MAGNET-NFR-distilroberta-base",
    "$-$ GCN": "MAGNET-NFR-no_gcn-distilroberta-base",
    "$-$ Ext. context": "MAGNET-NFR-no_xl-distilroberta-base",
    "$-$ Contrastive": "MAGNET-NFR-no_contrastive-distilroberta-base",
    "$-$ Meta-learning": "MAGNET-NFR-no_meta-distilroberta-base",
    "Encoder only": "MAGNET-NFR-roberta_only-distilroberta-base",
    "NoRBERT": "NoRBERT-bert-base-uncased",
    "TF-IDF + SVM": "TFIDF-LinearSVC",
}
CATS = ["Reliability", "Performance", "Usability", "Security"]


def load(preds, stem):
    out = {}
    for fp in glob.glob(os.path.join(preds, f"{stem}__seed*.csv")):
        s = int(re.search(r"seed(\d+)", fp).group(1))
        out[s] = pd.read_csv(fp).sort_values("item_id").reset_index(drop=True)
    if not out:
        raise SystemExit(f"no predictions for {stem} in {preds}")
    return dict(sorted(out.items()))


def fig1_architecture(out):
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.set_xlim(0, 10); ax.set_ylim(0, 7.0); ax.axis("off")

    def box(x, y, w, h, t, sub, fc, ec, fs=8.2):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05", fc=fc, ec=ec, lw=1.1))
        ax.text(x + w / 2, y + h * (0.66 if sub else 0.5), t, ha="center", va="center",
                fontsize=fs, weight="bold")
        if sub:
            ax.text(x + w / 2, y + h * 0.26, sub, ha="center", va="center",
                    fontsize=fs - 1.4, color="#333")

    def arr(p1, p2, rad=0.0):
        ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle="-|>", color="#555", lw=1.0,
                                     mutation_scale=10, connectionstyle=f"arc3,rad={rad}"))

    def tag(x, y, txt, c):
        ax.text(x, y, txt, fontsize=6.8, color=c, style="italic", ha="center")

    box(3.55, 6.30, 2.9, 0.52, "Requirement text", "", "#f4f4f4", "#999")
    box(0.30, 4.85, 2.95, 1.05, "Stage 1 · Encoder", "transformer, 256 tokens\n82.8M parameters", "#dbe7f0", "#1a5490")
    box(3.53, 4.85, 2.95, 1.05, "Stage 2 · GCN", "ISO/IEC 25010 graph\n+1.9M parameters", "#e0eee6", "#2e7d5b")
    box(6.76, 4.85, 2.95, 1.05, "Stage 3 · Ext. context", "relative position\n+28.9M parameters", "#f6e9dc", "#b5651d")
    tag(1.775, 4.70, "retained in every variant", "#1a5490")
    tag(5.005, 4.70, "removed in no_gcn", "#2e7d5b")
    tag(8.235, 4.70, "removed in no_xl", "#b5651d")
    for x in (1.775, 5.005, 8.235):
        arr((x, 6.28), (x, 5.94))
    box(2.60, 3.55, 4.8, 0.78, "Stage 4 · Cross-attention fusion",
        "12 heads — queries from Stage 1, keys/values from Stages 2–3", "#eeeaf4", "#6a4c93")
    arr((1.775, 4.83), (3.60, 4.35), rad=-0.16)
    arr((5.005, 4.83), (5.005, 4.35))
    arr((8.235, 4.83), (6.40, 4.35), rad=0.16)
    box(1.30, 2.35, 3.1, 0.78, "Stage 5 · Contrastive", "supervised, $\\tau = 0.07$", "#fdf0e3", "#c77d1a")
    box(5.60, 2.35, 3.1, 0.78, "Stage 6 · FOMAML", "episodic adaptation", "#fce8ec", "#a4133c")
    tag(2.85, 2.20, "removed in no_contrastive", "#c77d1a")
    tag(7.15, 2.20, "removed in no_meta", "#a4133c")
    arr((4.20, 3.53), (2.85, 3.15), rad=0.14)
    arr((5.80, 3.53), (7.15, 3.15), rad=-0.14)
    box(3.30, 1.05, 3.4, 0.78, "Stage 7 · Classification head",
        "$768 \\rightarrow 512 \\rightarrow 256 \\rightarrow k$, dropout 0.3", "#e6f0e8", "#37623f")
    arr((2.85, 2.33), (4.30, 1.85), rad=-0.14)
    arr((7.15, 2.33), (5.70, 1.85), rad=0.14)
    box(3.10, 0.10, 3.8, 0.60, "$k = 4$ evaluated categories",
        "Security · Usability · Performance · Reliability", "#f4f4f4", "#999")
    arr((5.0, 1.03), (5.0, 0.72))
    ax.text(0.05, 6.72, "Encoder-only variant retains Stage 1 and Stage 7 alone (82.8M parameters)",
            fontsize=7.0, color="#444", style="italic")
    plt.tight_layout(); plt.savefig(f"{out}/fig1_architecture.pdf", bbox_inches="tight"); plt.close()


def fig2_corpus(corpus_dir, out):
    c = pd.read_csv(f"{corpus_dir}/nfr_corpus.csv")
    vc = c.label.value_counts()
    ev = [(k, int(vc[k])) for k in ["Security", "Usability", "Performance", "Reliability"] if k in vc]
    ex = [("Maintainability", 34), ("Portability", 18)]  # from REPORT.txt, pre-scope
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9), gridspec_kw={"width_ratios": [1.25, 1]})
    names = [n for n, _ in ev + ex]; vals = [v for _, v in ev + ex]
    ax[0].barh(range(len(names)), vals, color=["#2c3e50"] * len(ev) + ["#c0392b"] * len(ex), height=0.68)
    ax[0].set_yticks(range(len(names))); ax[0].set_yticklabels(names, fontsize=8.5); ax[0].invert_yaxis()
    ax[0].set_xlabel("Records"); ax[0].set_xscale("log"); ax[0].set_xlim(10, 2200)
    for i, v in enumerate(vals):
        ax[0].text(v * 1.12, i, f"{v}", va="center", fontsize=8)
    ax[0].axhline(len(ev) - 0.5, color="#c0392b", lw=0.8, ls="--")
    ax[0].text(11, len(ev) + 0.6, "excluded: $n<40$", fontsize=7.5, color="#c0392b", style="italic")
    ax[0].set_title("(a) Corpus composition", fontsize=9, loc="left")
    for s in ["top", "right"]:
        ax[0].spines[s].set_visible(False)
    sh = [100 * v / len(c) for _, v in ev]
    floor = max(sh)
    ax[1].bar(range(len(ev)), sh, color=["#2c3e50", "#5d7a96", "#8fa8bd", "#c3d3de"][: len(ev)], width=0.66)
    ax[1].axhline(floor, color="#c0392b", lw=1.1, ls="--")
    ax[1].text(len(ev) - 0.58, floor + 1.9, f"majority-class\nfloor {floor:.2f}%",
               fontsize=7.5, color="#c0392b", ha="right")
    ax[1].set_xticks(range(len(ev))); ax[1].set_xticklabels(["Sec", "Usa", "Perf", "Rel"][: len(ev)], fontsize=8.5)
    ax[1].set_ylabel("Share of corpus (%)"); ax[1].set_ylim(0, 95)
    for i, v in enumerate(sh):
        ax[1].text(i, v + 2, f"{v:.1f}", ha="center", fontsize=8)
    ax[1].set_title("(b) Class imbalance", fontsize=9, loc="left")
    for s in ["top", "right"]:
        ax[1].spines[s].set_visible(False)
    plt.tight_layout(); plt.savefig(f"{out}/fig2_corpus.pdf", bbox_inches="tight"); plt.close()


def fig3_results(cfg, out):
    order = list(CONFIGS)
    mu, sd = [], []
    for k in order:
        f = np.array([f1_score(d.gold, d.pred, average="macro", zero_division=0) for d in cfg[k].values()])
        mu.append(f.mean()); sd.append(f.std(ddof=1))
    fig, ax = plt.subplots(figsize=(7.2, 3.1))
    y = np.arange(len(order))[::-1]
    cols = ["#1a5490"] + ["#5d7a96"] * 4 + ["#2e7d5b", "#2e7d5b", "#c0392b"]
    ax.axvspan(min(mu[:7]) - 0.0008, max(mu[:7]) + 0.0008, color="#e8eef3", zorder=0)
    ax.errorbar(mu, y, xerr=sd, fmt="none", ecolor="#666", elinewidth=1, capsize=2.5, zorder=2)
    ax.scatter(mu, y, s=44, c=cols, zorder=3, edgecolors="white", linewidths=0.7)
    ax.set_yticks(y); ax.set_yticklabels(order, fontsize=8.5)
    ax.set_xlabel("Macro $F_1$ (mean $\\pm$ s.d. over five repeats)")
    ax.set_xlim(0.862, 0.912)
    for i, m in enumerate(mu):
        ax.text(m, y[i] + 0.30, f"{m:.4f}", ha="center", fontsize=7.4)
    ax.text((min(mu[:7]) + max(mu[:7])) / 2, 7.55,
            f"seven transformer configurations, spread = {max(mu[:7]) - min(mu[:7]):.3f}",
            ha="center", fontsize=7.6, style="italic", color="#33475b")
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    plt.tight_layout(); plt.savefig(f"{out}/fig3_results.pdf", bbox_inches="tight"); plt.close()


def fig4_support(cfg, corpus_dir, out):
    c = pd.read_csv(f"{corpus_dir}/nfr_corpus.csv")
    N = [int((c.label == k).sum()) for k in CATS]
    fig, (ax, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.2), gridspec_kw={"width_ratios": [1.55, 1]})
    styles = [("Full MAGNET-NFR", "o", "#1a5490", 1.6, 1.0), ("$-$ GCN", "v", "#7f9db9", 1.0, 0.55),
              ("$-$ Ext. context", "<", "#7f9db9", 1.0, 0.55), ("$-$ Contrastive", ">", "#7f9db9", 1.0, 0.55),
              ("$-$ Meta-learning", "^", "#7f9db9", 1.0, 0.55), ("Encoder only", "s", "#2e7d5b", 1.6, 1.0),
              ("NoRBERT", "D", "#8e5aa8", 1.6, 1.0), ("TF-IDF + SVM", "X", "#c0392b", 1.6, 1.0)]
    allx, ally = [], []
    for key, mk, co, lw, al in styles:
        ys = [np.mean([precision_recall_fscore_support(d.gold, d.pred, labels=[cl], zero_division=0)[2][0]
                       for d in cfg[key].values()]) for cl in CATS]
        allx += N; ally += ys
        ax.plot(N, ys, marker=mk, color=co, ms=4.6 if lw > 1.2 else 3.2, lw=lw,
                label=key if lw > 1.2 else None, alpha=al, zorder=3 if lw > 1.2 else 2)
    sl, ic, r, _, _ = stats.linregress(np.log10(allx), ally)
    xx = np.logspace(np.log10(min(N) * 0.8), np.log10(max(N) * 1.3), 50)
    ax.plot(xx, ic + sl * np.log10(xx), "--", color="#444", lw=1.0, zorder=1)
    ax.text(300, 0.845, f"$F_1 = {ic:.3f} + {sl:.3f}\\,\\log_{{10}} n$\n$r^2 = {r ** 2:.2f}$",
            fontsize=7.6, color="#444")
    ax.set_xscale("log"); ax.set_xlabel("Class support $n$ (records, log scale)")
    ax.set_ylabel("Per-category $F_1$"); ax.set_ylim(0.74, 1.02)
    for n, cl in zip(N, CATS):
        ax.axvline(n, color="#e8e8e8", lw=0.7, zorder=0)
        ax.text(n, 1.012, cl, ha="center", fontsize=7.0, color="#444")
    ax.legend(fontsize=6.8, frameon=False, loc="lower right", handlelength=1.6)
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    ax.set_title("(a) Performance tracks class support", fontsize=9, loc="left")

    rows = []
    for meth, A in cfg.items():
        for cl in CATS:
            for d in A.values():
                rows.append({"method": meth, "cat": cl,
                             "f1": precision_recall_fscore_support(d.gold, d.pred, labels=[cl],
                                                                   zero_division=0)[2][0]})
    df = pd.DataFrame(rows); gm = df.f1.mean()
    ss_tot = ((df.f1 - gm) ** 2).sum()
    ss_cat = sum(len(g) * (g.f1.mean() - gm) ** 2 for _, g in df.groupby("cat"))
    ss_meth = sum(len(g) * (g.f1.mean() - gm) ** 2 for _, g in df.groupby("method"))
    vals = [100 * ss_cat / ss_tot, 100 * ss_meth / ss_tot, 100 * (ss_tot - ss_cat - ss_meth) / ss_tot]
    ax2.bar(range(3), vals, color=["#1a5490", "#c0392b", "#bbbbbb"], width=0.6)
    for i, v in enumerate(vals):
        ax2.text(i, v + 2.0, f"{v:.1f}%", ha="center", fontsize=8.4, weight="bold")
    ax2.set_xticks(range(3))
    ax2.set_xticklabels(["Category\n(class support)", "Method\n(architecture)", "Residual"], fontsize=7.6)
    ax2.set_ylabel("Share of variance in per-category $F_1$ (%)", fontsize=8.2)
    ax2.set_ylim(0, 104)
    for s in ["top", "right"]:
        ax2.spines[s].set_visible(False)
    ax2.set_title("(b) Variance decomposition", fontsize=9, loc="left")
    plt.tight_layout(); plt.savefig(f"{out}/fig4_support.pdf", bbox_inches="tight"); plt.close()
    return vals, (ic, sl, r ** 2)


def fig5_convergence(results_dir, corpus_dir, out):
    hits = glob.glob(f"{results_dir}/convergence_MAGNET-NFR-distilroberta-base*.csv")
    if not hits:
        print("  (no convergence log; skipping figure 5)")
        return
    d = pd.read_csv(sorted(hits)[0])
    c = pd.read_csv(f"{corpus_dir}/nfr_corpus.csv")
    floor = c.label.value_counts(normalize=True).max()
    fig, ax = plt.subplots(figsize=(4.4, 2.7))
    ax.plot(d.epoch, d.val_acc, marker="o", ms=3.5, color="#1a5490", lw=1.2, label="Validation accuracy")
    ax.plot(d.epoch, d.val_f1, marker="s", ms=3.5, color="#c0392b", lw=1.2, label="Validation macro $F_1$")
    ax.axhline(floor, color="#888", ls="--", lw=0.9)
    ax.text(d.epoch.max() - 0.2, floor + 0.013, "majority-class floor", fontsize=7, color="#888", ha="right")
    ax.set_xlabel("Epoch"); ax.set_ylabel("Score")
    ax.set_xticks(range(1, int(d.epoch.max()) + 1)); ax.set_ylim(0.28, 1.02)
    ax.legend(fontsize=7.4, frameon=False, loc="lower right")
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    plt.tight_layout(); plt.savefig(f"{out}/fig5_convergence.pdf", bbox_inches="tight"); plt.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--preds", default="predictions/pooled")
    ap.add_argument("--corpus", default="corpus")
    ap.add_argument("--results", default="results")
    ap.add_argument("--out", default="figures")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    cfg = {k: load(a.preds, v) for k, v in CONFIGS.items()}
    print(f"loaded {len(cfg)} configurations")

    fig1_architecture(a.out);                      print("  fig1_architecture.pdf")
    fig2_corpus(a.corpus, a.out);                  print("  fig2_corpus.pdf")
    fig3_results(cfg, a.out);                      print("  fig3_results.pdf")
    vals, fit = fig4_support(cfg, a.corpus, a.out); print("  fig4_support.pdf")
    fig5_convergence(a.results, a.corpus, a.out);  print("  fig5_convergence.pdf")

    print(f"\nvariance: category {vals[0]:.1f}%  method {vals[1]:.1f}%  residual {vals[2]:.1f}%")
    print(f"fit: F1 = {fit[0]:.4f} + {fit[1]:.4f} log10(n),  r^2 = {fit[2]:.4f}")


if __name__ == "__main__":
    main()
