#!/usr/bin/env python3
"""
verify_paper.py — check every quantitative claim in the paper against the data.

This script exists so that a reader does not have to take any reported figure on
trust. It recomputes each number from corpus/ and predictions/pooled/ and compares
it with the value printed in the manuscript, which is hard-coded below.

Exit status is 0 if every claim matches and 1 otherwise.

USAGE
    python code/verify_paper.py
"""
import glob
import os
import re
import sys

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import accuracy_score, f1_score, precision_recall_fscore_support

PREDS = "predictions/pooled"
CORPUS = "corpus/nfr_corpus.csv"

CONFIGS = {
    "full": "MAGNET-NFR-distilroberta-base",
    "no_gcn": "MAGNET-NFR-no_gcn-distilroberta-base",
    "no_xl": "MAGNET-NFR-no_xl-distilroberta-base",
    "no_con": "MAGNET-NFR-no_contrastive-distilroberta-base",
    "no_meta": "MAGNET-NFR-no_meta-distilroberta-base",
    "ronly": "MAGNET-NFR-roberta_only-distilroberta-base",
    "norbert": "NoRBERT-bert-base-uncased",
    "tfidf": "TFIDF-LinearSVC",
}
CATS = ["Security", "Usability", "Performance", "Reliability"]

results = []


def check(label, computed, paper):
    ok = computed == paper
    results.append((label, ok, computed, paper))


def load(stem):
    out = {}
    for fp in glob.glob(os.path.join(PREDS, f"{stem}__seed*.csv")):
        s = int(re.search(r"seed(\d+)", fp).group(1))
        out[s] = pd.read_csv(fp).sort_values("item_id").reset_index(drop=True)
    return dict(sorted(out.items()))


def mcnemar(A, B):
    n12 = n21 = 0
    for s in sorted(set(A) & set(B)):
        a, b = A[s], B[s]
        assert (a.item_id.values == b.item_id.values).all(), "item sets differ"
        ca = a.gold.values == a.pred.values
        cb = b.gold.values == b.pred.values
        n12 += int((ca & ~cb).sum())
        n21 += int((~ca & cb).sum())
    chi2 = (abs(n12 - n21) - 1) ** 2 / (n12 + n21)
    return n12, n21, chi2, float(1 - stats.chi2.cdf(chi2, 1))


def main():
    if not os.path.exists(CORPUS):
        sys.exit("run this from the repository root: python code/verify_paper.py")

    cfg = {k: load(v) for k, v in CONFIGS.items()}
    missing = [k for k, v in cfg.items() if not v]
    if missing:
        sys.exit(f"missing predictions for: {missing}")

    corpus = pd.read_csv(CORPUS)

    # ---- integrity -------------------------------------------------
    print("=" * 66)
    print("INTEGRITY")
    print("=" * 66)
    sigs = {(k, s): tuple(d.item_id) for k, A in cfg.items() for s, d in A.items()}
    print(f"  identical item set across all {len(sigs)} pooled sets: "
          f"{'yes' if len(set(sigs.values())) == 1 else 'NO'}")
    print(f"  records per set: {len(next(iter(cfg['full'].values())))}")
    print(f"  repeats per configuration: {len(cfg['full'])}")

    # ---- corpus ----------------------------------------------------
    print("\n" + "=" * 66)
    print("CORPUS (Section 3.1, Table 2)")
    print("=" * 66)
    vc = corpus.label.value_counts()
    floor = vc.max() / len(corpus)
    check("corpus size", str(len(corpus)), "1667")
    check("majority floor", f"{floor * 100:.2f}", "80.56")
    for cat, want in [("Security", "1343"), ("Usability", "150"),
                      ("Performance", "106"), ("Reliability", "68")]:
        check(f"{cat} support", str(int(vc[cat])), want)

    # ---- main results ----------------------------------------------
    print("\n" + "=" * 66)
    print("MAIN RESULTS (Table 4)")
    print("=" * 66)
    paper = {
        "full": ("96.22", "0.8984"), "no_gcn": ("96.14", "0.8955"),
        "no_xl": ("96.38", "0.8980"), "no_con": ("96.09", "0.8933"),
        "no_meta": ("96.30", "0.8983"), "ronly": ("96.32", "0.8966"),
        "norbert": ("96.30", "0.8961"), "tfidf": ("95.48", "0.8730"),
    }
    for k, (pa, pf) in paper.items():
        a = np.array([accuracy_score(d.gold, d.pred) for d in cfg[k].values()])
        f = np.array([f1_score(d.gold, d.pred, average="macro", zero_division=0)
                      for d in cfg[k].values()])
        check(f"{k} accuracy", f"{a.mean() * 100:.2f}", pa)
        check(f"{k} macro F1", f"{f.mean():.4f}", pf)
        print(f"  {k:9s} acc {a.mean() * 100:6.2f} +/- {a.std(ddof=1) * 100:.2f}   "
              f"macro F1 {f.mean():.4f} +/- {f.std(ddof=1):.4f}")

    a_full = np.array([accuracy_score(d.gold, d.pred) for d in cfg["full"].values()])
    check("margin over floor", f"{a_full.mean() * 100 - floor * 100:.2f}", "15.66")

    # ---- ablation tests --------------------------------------------
    print("\n" + "=" * 66)
    print("ABLATION (Section 4.3)")
    print("=" * 66)
    for k, pc, pp in [("no_gcn", "0.18", "0.67"), ("no_xl", "0.78", "0.38"),
                      ("no_con", "0.54", "0.46"), ("no_meta", "0.20", "0.66"),
                      ("ronly", "0.27", "0.60"), ("norbert", "0.14", "0.71")]:
        n12, n21, chi2, p = mcnemar(cfg["full"], cfg[k])
        check(f"{k} chi2", f"{chi2:.2f}", pc)
        check(f"{k} p", f"{p:.2f}", pp)
        print(f"  full vs {k:9s} n12={n12:4d} n21={n21:4d}  chi2={chi2:5.2f}  p={p:.3f}"
              f"  {'significant' if p < 0.05 else 'not significant'}")

    n12, n21, chi2, p = mcnemar(cfg["full"], cfg["no_gcn"])
    check("gcn n12", str(n12), "105")
    check("gcn n21", str(n21), "98")

    keys = ["full", "no_gcn", "no_xl", "no_con", "no_meta", "ronly", "norbert"]
    common = sorted(set.intersection(*[set(cfg[k]) for k in keys]))
    mat = np.array([[accuracy_score(cfg[k][s].gold, cfg[k][s].pred) for k in keys] for s in common])
    fchi, fp = stats.friedmanchisquare(*mat.T)
    check("friedman chi2", f"{fchi:.2f}", "4.94")
    check("friedman p", f"{fp:.2f}", "0.55")
    print(f"\n  Friedman across 7 transformer configurations: "
          f"chi2={fchi:.2f}, df=6, p={fp:.3f}")

    # ---- transformer vs classical ----------------------------------
    print("\n" + "=" * 66)
    print("TRANSFORMER vs CLASSICAL (Section 4.2)")
    print("=" * 66)
    for k, pc in [("full", "9.54"), ("ronly", "13.37"), ("norbert", "14.32")]:
        n12, n21, chi2, p = mcnemar(cfg[k], cfg["tfidf"])
        check(f"{k} vs tfidf chi2", f"{chi2:.2f}", pc)
        print(f"  {k:8s} vs TF-IDF  n12={n12:4d} n21={n21:4d}  chi2={chi2:5.2f}  p={p:.2e}")
    check("tfidf n12", str(mcnemar(cfg["full"], cfg["tfidf"])[0]), "226")
    check("tfidf n21", str(mcnemar(cfg["full"], cfg["tfidf"])[1]), "164")

    # ---- per-category ----------------------------------------------
    print("\n" + "=" * 66)
    print("PER-CATEGORY (Table 5)")
    print("=" * 66)
    for cat, pf in [("Security", "0.982"), ("Usability", "0.887"),
                    ("Performance", "0.914"), ("Reliability", "0.811")]:
        fs = [precision_recall_fscore_support(d.gold, d.pred, labels=[cat], zero_division=0)[2][0]
              for d in cfg["full"].values()]
        check(f"{cat} F1", f"{np.mean(fs):.3f}", pf)
        print(f"  {cat:12s} n={int((corpus.label == cat).sum()):5d}  F1 {np.mean(fs):.3f}")

    # ---- variance decomposition ------------------------------------
    print("\n" + "=" * 66)
    print("VARIANCE DECOMPOSITION (Section 4.5, Figure 4)")
    print("=" * 66)
    rows = []
    for meth, A in cfg.items():
        for cat in CATS:
            for d in A.values():
                rows.append({"method": meth, "cat": cat,
                             "f1": precision_recall_fscore_support(d.gold, d.pred, labels=[cat],
                                                                   zero_division=0)[2][0]})
    df = pd.DataFrame(rows)
    gm = df.f1.mean()
    ss_tot = ((df.f1 - gm) ** 2).sum()
    ss_cat = sum(len(g) * (g.f1.mean() - gm) ** 2 for _, g in df.groupby("cat"))
    ss_meth = sum(len(g) * (g.f1.mean() - gm) ** 2 for _, g in df.groupby("method"))
    check("category variance", f"{100 * ss_cat / ss_tot:.1f}", "91.5")
    check("method variance", f"{100 * ss_meth / ss_tot:.1f}", "1.5")
    print(f"  category {100 * ss_cat / ss_tot:.1f}%   method {100 * ss_meth / ss_tot:.1f}%   "
          f"residual {100 * (ss_tot - ss_cat - ss_meth) / ss_tot:.1f}%")

    bycat = df.groupby("cat").f1.mean()
    bymeth = df.groupby("method").f1.mean()
    ratio = (bycat.max() - bycat.min()) / (bymeth.max() - bymeth.min())
    check("range ratio", f"{ratio:.1f}", "6.9")
    print(f"  category range {bycat.max() - bycat.min():.4f} is {ratio:.1f}x "
          f"the method range {bymeth.max() - bymeth.min():.4f}")

    # fit over method-category means, which is what Figure 4(a) plots
    n_by_cat = {c: int((corpus.label == c).sum()) for c in CATS}
    cell = df.groupby(["method", "cat"], as_index=False).f1.mean()
    x = np.log10([n_by_cat[c] for c in cell.cat])
    sl, ic, r, _, _ = stats.linregress(x, cell.f1.values)
    check("fit slope", f"{sl:.3f}", "0.114")
    check("fit r2", f"{r ** 2:.2f}", "0.80")
    print(f"  F1 = {ic:.3f} + {sl:.3f} log10(n),  r^2 = {r ** 2:.2f}")

    # ---- report ----------------------------------------------------
    bad = [x for x in results if not x[1]]
    print("\n" + "=" * 66)
    print(f"{len(results) - len(bad)} of {len(results)} claims verified")
    print("=" * 66)
    if bad:
        for label, _, got, want in bad:
            print(f"  MISMATCH  {label}: paper says {want}, data gives {got}")
        sys.exit(1)
    print("Every quantitative claim in the paper matches the released data.")


if __name__ == "__main__":
    main()
