#!/usr/bin/env python3
"""Run/score the pair-aware contrastive fairness experiment.

Primary contrast:
  full + pair-aware batching
  vs
  no_contrastive + the SAME pair-aware batching

This isolates whether supervised contrastive learning contributes when every anchor
is guaranteed a same-class positive, while keeping the sampler identical in both arms.

The runner is resumable. Existing valid prediction CSVs are skipped.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score


ARCHS = ["full", "no_contrastive"]


def parse_reps(s):
    if s is None or s == "all":
        return list(range(5))
    return [int(x) for x in s.split(",") if x.strip() != ""]


def pred_name(arch, backbone, rep, fold):
    base = "MAGNET-NFR" if arch == "full" else f"MAGNET-NFR-{arch}"
    return f"{base}-{backbone}-pairaware__rep{rep}fold{fold}.csv"


def valid_prediction(path, corpus, folds, rep, fold):
    p = Path(path)
    if not p.exists():
        return False
    try:
        d = pd.read_csv(p)
    except Exception:
        return False
    if set(["item_id", "gold", "pred"]) - set(d.columns):
        return False
    f = folds[(folds.rep == rep) & (folds.fold == fold)]
    expected = set(f.item_id)
    got = set(d.item_id)
    return got == expected and len(d) == len(expected)


def run_neural(args):
    corpus = pd.read_csv(args.corpus)
    folds = pd.read_csv(args.folds)
    reps = parse_reps(args.reps)
    out = Path(args.work) / "predictions"
    logs = Path(args.work) / "logs"
    out.mkdir(parents=True, exist_ok=True)
    logs.mkdir(parents=True, exist_ok=True)

    total = len(reps) * 5 * len(ARCHS)
    k = 0
    for rep in reps:
        for fold in range(5):
            for arch in ARCHS:
                k += 1
                pred = out / pred_name(arch, args.backbone, rep, fold)
                if valid_prediction(pred, corpus, folds, rep, fold):
                    print(f"[{k}/{total}] RESUME/SKIP rep={rep} fold={fold} arch={arch}")
                    continue

                log = logs / f"rep{rep}_fold{fold}_{arch}.log"
                cmd = [
                    sys.executable, "code/train_pairaware.py",
                    "--variant", arch,
                    "--seed", str(args.seed),
                    "--corpus", args.corpus,
                    "--folds", args.folds,
                    "--rep", str(rep),
                    "--fold", str(fold),
                    "--out", str(out),
                    "--backbone", args.backbone,
                    "--epochs", str(args.epochs),
                    "--batch-size", str(args.batch_size),
                    "--pair-aware-batches",
                ]
                print(f"[{k}/{total}] RUN rep={rep} fold={fold} arch={arch}")
                with open(log, "w") as fh:
                    r = subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT)
                if r.returncode != 0:
                    print(f"  !! FAILED; see {log}")
                else:
                    print(f"  OK -> {pred}")


def pool_complete_repeat(work, corpus, folds, arch, rep, backbone):
    parts = []
    for fold in range(5):
        p = Path(work) / "predictions" / pred_name(arch, backbone, rep, fold)
        if not valid_prediction(p, corpus, folds, rep, fold):
            return None
        d = pd.read_csv(p)
        d["rep"] = rep
        d["fold"] = fold
        parts.append(d)
    x = pd.concat(parts, ignore_index=True)
    if len(x) != len(corpus) or x.item_id.nunique() != len(corpus):
        raise RuntimeError(f"Bad pooled repeat {rep} {arch}: {len(x)} rows, {x.item_id.nunique()} ids")
    return x


def paired_bootstrap(full_reps, nocon_reps, n_boot=4000, seed=20360909):
    common = sorted(set(full_reps) & set(nocon_reps))
    if not common:
        return None

    # same canonical item order in every repeat
    ids = full_reps[common[0]].item_id.tolist()
    N = len(ids)
    full_pred, nocon_pred, gold = {}, {}, {}
    for rep in common:
        a = full_reps[rep].set_index("item_id").loc[ids]
        b = nocon_reps[rep].set_index("item_id").loc[ids]
        if not (a.gold.to_numpy() == b.gold.to_numpy()).all():
            raise RuntimeError("Gold mismatch between arms")
        full_pred[rep] = a.pred.to_numpy()
        nocon_pred[rep] = b.pred.to_numpy()
        gold[rep] = a.gold.to_numpy()

    def avg_delta(indices=None):
        vals = []
        for rep in common:
            y = gold[rep] if indices is None else gold[rep][indices]
            pa = full_pred[rep] if indices is None else full_pred[rep][indices]
            pb = nocon_pred[rep] if indices is None else nocon_pred[rep][indices]
            vals.append(
                f1_score(y, pa, average="macro", zero_division=0)
                - f1_score(y, pb, average="macro", zero_division=0)
            )
        return float(np.mean(vals))

    obs = avg_delta()
    rng = np.random.default_rng(seed)
    boots = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        idx = rng.integers(0, N, size=N)
        boots[i] = avg_delta(idx)

    lo, hi = np.percentile(boots, [2.5, 97.5])
    p = 2 * min((boots <= 0).mean(), (boots >= 0).mean())
    p = min(1.0, float(p))
    return {
        "comparison": "pairaware_full_minus_pairaware_no_contrastive",
        "n_complete_repeats": len(common),
        "delta_macro_f1": obs,
        "ci95_lo": float(lo),
        "ci95_hi": float(hi),
        "bootstrap_p_two_sided": p,
        "n_boot": int(n_boot),
        "bootstrap_unit": "record; macro-F1 computed per repeat then averaged across repeats",
        "seed": int(seed),
    }


def score(args):
    work = Path(args.work)
    work.mkdir(parents=True, exist_ok=True)
    corpus = pd.read_csv(args.corpus)
    folds = pd.read_csv(args.folds)

    fold_rows = []
    complete_count = 0
    for rep in range(5):
        for fold in range(5):
            for arch in ARCHS:
                p = work / "predictions" / pred_name(arch, args.backbone, rep, fold)
                if not valid_prediction(p, corpus, folds, rep, fold):
                    continue
                complete_count += 1
                d = pd.read_csv(p)
                fold_rows.append({
                    "rep": rep,
                    "fold": fold,
                    "arch": arch,
                    "n": len(d),
                    "accuracy": accuracy_score(d.gold, d.pred),
                    "macro_f1": f1_score(d.gold, d.pred, average="macro", zero_division=0),
                    "prediction": str(p),
                })

    fold_df = pd.DataFrame(fold_rows)
    fold_df.to_csv(work / "pairaware_fold_metrics.csv", index=False)

    rep_rows = []
    pooled = {a: {} for a in ARCHS}
    for rep in range(5):
        for arch in ARCHS:
            x = pool_complete_repeat(work, corpus, folds, arch, rep, args.backbone)
            if x is None:
                continue
            pooled[arch][rep] = x
            rep_rows.append({
                "rep": rep,
                "arch": arch,
                "n": len(x),
                "accuracy": accuracy_score(x.gold, x.pred),
                "macro_f1": f1_score(x.gold, x.pred, average="macro", zero_division=0),
            })

    rep_df = pd.DataFrame(rep_rows)
    rep_df.to_csv(work / "pairaware_rep_metrics.csv", index=False)

    if len(rep_df):
        summary = (
            rep_df.groupby("arch", as_index=False)
            .agg(
                n_complete_repeats=("rep", "nunique"),
                accuracy_mean=("accuracy", "mean"),
                accuracy_sd=("accuracy", "std"),
                macro_f1_mean=("macro_f1", "mean"),
                macro_f1_sd=("macro_f1", "std"),
            )
        )
    else:
        summary = pd.DataFrame()
    summary.to_csv(work / "pairaware_summary.csv", index=False)

    boot = paired_bootstrap(
        pooled["full"], pooled["no_contrastive"],
        n_boot=args.bootstrap, seed=args.bootstrap_seed
    )
    if boot is not None:
        (work / "pairaware_bootstrap_full_vs_no_contrastive.json").write_text(
            json.dumps(boot, indent=2)
        )

    completion = {
        "neural_fold_runs_complete": int(complete_count),
        "neural_fold_runs_expected": 50,
        "complete_repeats_full": int(len(pooled["full"])),
        "complete_repeats_no_contrastive": int(len(pooled["no_contrastive"])),
    }
    (work / "completion.json").write_text(json.dumps(completion, indent=2))

    print("\nCOMPLETION")
    print(json.dumps(completion, indent=2))
    if len(rep_df):
        print("\nPER-REPEAT METRICS")
        print(rep_df.to_string(index=False))
    if len(summary):
        print("\nSUMMARY")
        print(summary.to_string(index=False))
    if boot is not None:
        print("\nPAIRED BOOTSTRAP: PAIR-AWARE FULL - PAIR-AWARE NO-CONTRASTIVE")
        print(json.dumps(boot, indent=2))
    print(f"\nOutputs: {work}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", required=True)
    ap.add_argument("--corpus", default="corpus/nfr_corpus.csv")
    ap.add_argument("--folds", default="corpus/folds.csv")
    ap.add_argument("--backbone", default="distilroberta-base")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--reps", default="all", help="e.g. 0 or 0,1 or all")
    ap.add_argument("--bootstrap", type=int, default=4000)
    ap.add_argument("--bootstrap-seed", type=int, default=20360909)
    ap.add_argument("--run-neural", action="store_true")
    ap.add_argument("--score", action="store_true")
    args = ap.parse_args()

    if not args.run_neural and not args.score:
        ap.error("Choose --run-neural and/or --score")
    if args.run_neural:
        run_neural(args)
    if args.score:
        score(args)


if __name__ == "__main__":
    main()
