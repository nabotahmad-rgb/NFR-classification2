#!/usr/bin/env python3
"""Audit positive-pair availability for MAGNET-NFR supervised contrastive learning.

This reproduces the training-set construction used by code/train.py:
  * one outer CV fold held out as test
  * 15% of the remaining records held out for validation with stratification
  * random shuffled training batches of size 16

For an anchor from class c, the supervised contrastive loss is active only when at
least one other item of class c appears in the same batch.  Under DataLoader(...,
shuffle=True), batch membership is a random partition of the training set.  This
script computes the exact expected probability of a same-class positive for each
class/fold, accounting for the final partial batch.

No neural training or GPU is required.
"""

import argparse
import json
from math import comb
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split


def prob_positive_exact(n_total: int, n_class: int, batch_size: int) -> float:
    """Expected P(anchor has >=1 same-class batchmate) under random shuffling.

    Accounts exactly for a possible final partial batch.  Conditional on a batch of
    size s, the no-positive probability is hypergeometric:
      C(N-Nc, s-1) / C(N-1, s-1).
    """
    if n_class <= 1 or n_total <= 1:
        return 0.0

    q, r = divmod(n_total, batch_size)

    def p_for_batch_size(s: int) -> float:
        if s <= 1:
            return 0.0
        k = s - 1
        if n_total - n_class < k:
            p_no = 0.0
        else:
            p_no = comb(n_total - n_class, k) / comb(n_total - 1, k)
        return 1.0 - p_no

    if r == 0:
        return p_for_batch_size(batch_size)

    p_full = p_for_batch_size(batch_size)
    p_last = p_for_batch_size(r)
    return (q * batch_size / n_total) * p_full + (r / n_total) * p_last


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--corpus', default='corpus/nfr_corpus.csv')
    ap.add_argument('--folds', default='corpus/folds.csv')
    ap.add_argument('--out', default='results/contrastive_batch_audit')
    ap.add_argument('--seed', type=int, default=42,
                    help='Validation-split seed; paper training uses 42.')
    ap.add_argument('--batch-size', type=int, default=16)
    ap.add_argument('--epochs', type=int, default=10)
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    corpus = pd.read_csv(args.corpus)
    folds = pd.read_csv(args.folds)
    classes = sorted(corpus['label'].unique())

    rows = []
    for rep in sorted(folds['rep'].unique()):
        f_rep = folds[folds['rep'] == rep]
        for fold in sorted(f_rep['fold'].unique()):
            test_ids = set(f_rep.loc[f_rep['fold'] == fold, 'item_id'])
            rest = corpus[~corpus['item_id'].isin(test_ids)].reset_index(drop=True)
            tr, va = train_test_split(
                rest,
                test_size=0.15,
                stratify=rest['label'],
                random_state=args.seed,
            )

            n_total = len(tr)
            counts = tr['label'].value_counts().to_dict()
            last_batch = n_total % args.batch_size

            for cls in classes:
                n_class = int(counts.get(cls, 0))
                p_pos = prob_positive_exact(n_total, n_class, args.batch_size)
                total_exp = n_class * args.epochs
                active_exp = total_exp * p_pos
                inactive_exp = total_exp * (1.0 - p_pos)
                p_never = (1.0 - p_pos) ** args.epochs

                rows.append({
                    'rep': int(rep),
                    'fold': int(fold),
                    'class': cls,
                    'train_n': n_total,
                    'class_n': n_class,
                    'batch_size': args.batch_size,
                    'last_batch_size': last_batch,
                    'expected_positive_probability': p_pos,
                    'expected_active_anchor_pct': 100.0 * p_pos,
                    'expected_inactive_anchor_pct': 100.0 * (1.0 - p_pos),
                    'expected_active_anchor_exposures_10ep': active_exp,
                    'expected_inactive_anchor_exposures_10ep': inactive_exp,
                    'prob_anchor_never_gets_positive_over_epochs': p_never,
                })

    detail = pd.DataFrame(rows)
    detail_path = out / 'contrastive_positive_pair_fold_audit.csv'
    detail.to_csv(detail_path, index=False)

    summary = (
        detail.groupby('class', as_index=False)
        .agg(
            train_class_n_mean=('class_n', 'mean'),
            train_class_n_min=('class_n', 'min'),
            train_class_n_max=('class_n', 'max'),
            active_anchor_pct_mean=('expected_active_anchor_pct', 'mean'),
            active_anchor_pct_min=('expected_active_anchor_pct', 'min'),
            active_anchor_pct_max=('expected_active_anchor_pct', 'max'),
            inactive_anchor_pct_mean=('expected_inactive_anchor_pct', 'mean'),
            expected_active_exposures_10ep_mean=('expected_active_anchor_exposures_10ep', 'mean'),
            expected_inactive_exposures_10ep_mean=('expected_inactive_anchor_exposures_10ep', 'mean'),
            prob_never_positive_10ep_mean=('prob_anchor_never_gets_positive_over_epochs', 'mean'),
        )
        .sort_values('active_anchor_pct_mean')
    )
    summary_path = out / 'contrastive_positive_pair_summary.csv'
    summary.to_csv(summary_path, index=False)

    # Overall expected participation, weighted by number of class anchors in each fold.
    overall_by_fold = []
    for (rep, fold), g in detail.groupby(['rep', 'fold']):
        overall = np.average(
            g['expected_positive_probability'].to_numpy(),
            weights=g['class_n'].to_numpy(),
        )
        overall_by_fold.append(overall)

    audit = {
        'method': (
            'Exact hypergeometric expectation under uniformly shuffled batches, '
            'matching DataLoader(..., shuffle=True); validation split reproduced '
            'with stratified 15% holdout and random_state=42.'
        ),
        'corpus_n': int(len(corpus)),
        'n_repeats': int(folds['rep'].nunique()),
        'n_folds_per_repeat': int(folds.groupby('rep')['fold'].nunique().max()),
        'n_train_fold_conditions': int(detail[['rep', 'fold']].drop_duplicates().shape[0]),
        'batch_size': args.batch_size,
        'epochs': args.epochs,
        'validation_seed': args.seed,
        'overall_expected_active_anchor_pct_mean': float(100 * np.mean(overall_by_fold)),
        'overall_expected_active_anchor_pct_min': float(100 * np.min(overall_by_fold)),
        'overall_expected_active_anchor_pct_max': float(100 * np.max(overall_by_fold)),
        'class_summary': summary.to_dict(orient='records'),
        'interpretation_guardrail': (
            'This audit measures whether an anchor can contribute to the supervised '
            'contrastive objective under the paper batching scheme. It does not by '
            'itself estimate how much classification performance would change under '
            'a class-aware sampler.'
        ),
    }
    json_path = out / 'contrastive_positive_pair_audit.json'
    json_path.write_text(json.dumps(audit, indent=2), encoding='utf-8')

    print('\nCONTRASTIVE POSITIVE-PAIR AUDIT')
    print(f'Fold conditions: {audit["n_train_fold_conditions"]}')
    print(f'Batch size: {args.batch_size}; epochs: {args.epochs}')
    print('\nPer-class expected anchor participation:')
    show = summary[[
        'class', 'train_class_n_mean', 'active_anchor_pct_mean',
        'inactive_anchor_pct_mean', 'prob_never_positive_10ep_mean'
    ]].copy()
    print(show.to_string(index=False, formatters={
        'train_class_n_mean': '{:.1f}'.format,
        'active_anchor_pct_mean': '{:.2f}'.format,
        'inactive_anchor_pct_mean': '{:.2f}'.format,
        'prob_never_positive_10ep_mean': '{:.6f}'.format,
    }))
    print(f'\nOverall expected active anchors: '
          f'{audit["overall_expected_active_anchor_pct_mean"]:.2f}%')
    print('\nOutputs:')
    print(f'  {detail_path}')
    print(f'  {summary_path}')
    print(f'  {json_path}')


if __name__ == '__main__':
    main()
